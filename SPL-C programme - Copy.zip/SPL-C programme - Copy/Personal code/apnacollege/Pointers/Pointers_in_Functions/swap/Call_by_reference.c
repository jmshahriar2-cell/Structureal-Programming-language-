#include<stdio.h>

//function declaration
void swap(int a, int b);
void _swap(int *a, int *b);

//function call
int main(){
    int x = 3, y = 5;
    _swap(&x,&y);
    printf("x = %d & y = %d\n", x, y);
return 0;
}
 //call by reference
void _swap(int *a, int *b){
    int t = *a;
    *a = *b;
    *b = t;
}

//function definition
 //call by value
void swap(int a, int b){
    int t = a;
    a = b;
    b = t;
    printf("a = %d & b = %d\n", a,b);
}